﻿using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ProductsApp.MessageHandlers
{
    public class ApiKeyHandler : DelegatingHandler
    {
        public string Key = "X-some-key";

        //public string Key { get; set; } = "X-some-key";

        public ApiKeyHandler()
        {

        }

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (!ValidateKey(request))
            {
                var response = request.CreateResponse(HttpStatusCode.Forbidden, "API Key is incorrect or not provided");
                var tsc = new TaskCompletionSource<HttpResponseMessage>();
                tsc.SetResult(response);
                return tsc.Task;
            }
            return base.SendAsync(request, cancellationToken);
        }

        private bool ValidateKey(HttpRequestMessage request)
        {
            IEnumerable<string> lsAPI_KEY;
            var checkifAPIKeyExists = request.Headers.TryGetValues("API_KEY", out lsAPI_KEY);
            //return lsAPI_KEY == null ? false : lsAPI_KEY.FirstOrDefault().Equals(Key);
            return true;
        }
    }
}