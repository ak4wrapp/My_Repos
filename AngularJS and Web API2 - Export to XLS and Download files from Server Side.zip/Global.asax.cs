﻿using ProductsApp.MessageHandlers;
using System.Web.Http;

namespace ProductsApp
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);

            GlobalConfiguration.Configuration.MessageHandlers.Add(new ApiKeyHandler());
        }
    }
}
