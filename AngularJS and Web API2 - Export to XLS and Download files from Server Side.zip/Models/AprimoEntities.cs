﻿using System;
using System.Collections.Generic;

namespace ProductsApp.Models.AprimoEntities
{
    public class ConfigOptions
    {
        public List<string> EmailSegments { get; set; }
        public List<string> EmailType { get; set; }
        public List<string> RecoveryModule { get; set; }
        public List<string> FootersForCreativeBuilds { get; set; }
        public List<string> HarmonyCategory { get; set; }
        public List<string> HarmonyEmailSettings { get; set; }
        public List<string> Country { get; set; }
        public List<string> Language { get; set; }
        public List<string> AM_PM { get; set; }
        public List<string> HarmonyLinkTag { get; set; }
        public List<string> HarmonyLinkType { get; set; }
        public ConfigOptions()
        {
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            EmailSegments = new List<string>();
            EmailSegments.Add("All");
            EmailSegments.Add("Consumer");
            EmailSegments.Add("Merchant");
            EmailSegments.Add("PayPal Employees");

            EmailType = new List<string>();
            EmailType.Add("Account Related (Legal, Policy,Statements, PFS)");
            EmailType.Add("Co - Marketing(Co - Branded)");
            EmailType.Add("PayPal Credit/ BML(Credit)");
            EmailType.Add("GE(Credit)");
            EmailType.Add("CRM");
            EmailType.Add("Omnichannel / Wildfire");
            EmailType.Add("Prepaid Card");
            EmailType.Add("FMX");
            EmailType.Add("PP Select");
            EmailType.Add("PPMN / CLO");
            EmailType.Add("Debit Card");
            EmailType.Add("PayPal Here");
            EmailType.Add("Other");

            RecoveryModule = new List<string>();
            RecoveryModule.Add("US_Consumer_Recovery Module");
            RecoveryModule.Add("US_Merchant_Recovery Module");
            RecoveryModule.Add("CA_Consumer_Recovery Module_EN");
            RecoveryModule.Add("CA_Consumer_Recovery Module_FR");
            RecoveryModule.Add("CA_Merchant_Recovery Module_EN");
            RecoveryModule.Add("CA_Merchant_Recovery Module_FR");

            FootersForCreativeBuilds = new List<string>();
            FootersForCreativeBuilds.Add("Footer_NA_US_NewsAndPromotions_WorkingCapital");
            FootersForCreativeBuilds.Add("Footer_NA_US_AcctInfoTrans");
            FootersForCreativeBuilds.Add("Footer_NA_US_NewsAndPromotions_Consumer");
            FootersForCreativeBuilds.Add("Footer_NA_US_NewsAndPromotions_Merchant");
            FootersForCreativeBuilds.Add("Footer_NA_CA_NewsAndPromotions_EN");
            FootersForCreativeBuilds.Add("Footer_NA_CA_NewsAndPromotions_FR");
            FootersForCreativeBuilds.Add("Footer_NA_CA_AcctInfoTrans_English_EN");
            FootersForCreativeBuilds.Add("Footer_NA_CA_AcctInfoTrans_French_FR");

            HarmonyCategory = new List<string>();
            HarmonyCategory.Add("Birthday/Anniversary");
            HarmonyCategory.Add("eNewsletter/Editorial");
            HarmonyCategory.Add("Marketing(Sales/Special Offer)");
            HarmonyCategory.Add("Legal");
            HarmonyCategory.Add("Marketing");
            HarmonyCategory.Add("Proof/Seed Deployment");
            HarmonyCategory.Add("Other");

            HarmonyEmailSettings = new List<string>();
            HarmonyEmailSettings.Add("PayPal - USA_Default - paypal@mail.paypal.com");
            HarmonyEmailSettings.Add("PayPal Canada - paypal@mail.paypal.ca");

            Country = new List<string>();
            Country.Add("US");
            Country.Add("CA");

            Language = new List<string>();
            Language.Add("English");

            AM_PM = new List<string>();
            AM_PM.Add("AM");
            AM_PM.Add("PM");

            HarmonyLinkTag = new List<string>();
            HarmonyLinkTag.Add("HDR");
            HarmonyLinkTag.Add("FTR");
            HarmonyLinkTag.Add("CTA");
            HarmonyLinkTag.Add("OOL");
            HarmonyLinkTag.Add("GEN");
            HarmonyLinkTag.Add("UNSUB");

            HarmonyLinkType = new List<string>();
            HarmonyLinkType.Add("Redirect");
            HarmonyLinkType.Add("Form");
            HarmonyLinkType.Add("Image");
        }
    }

    public class EpsilonInfo
    {
        public Paypal_Asset Paypal_Asset { get; set; }
        public PayPalCampaignBuild PayPalCampaignBuild { get; set; }
        public Campaign_LocaInfo Campaign_LocaInfo { get; set; }
        public List<SeedList> SeedList { get; set; } //= new List<SeedList>();
        public List<TestQAList> TestQAList { get; set; } //= new List<TestQAList>();
        public List<LinkTable> LinkTable { get; set; } //= new List<LinkTable>();

        public EpsilonInfo()
        {
            Paypal_Asset = new Paypal_Asset();
            PayPalCampaignBuild = new PayPalCampaignBuild();
            Campaign_LocaInfo = new Campaign_LocaInfo();
            SeedList = new List<SeedList>();
            TestQAList = new List<TestQAList>();
            LinkTable = new List<LinkTable>();

            if (Paypal_Asset.Campaign != null
                && Paypal_Asset.Campaign.Deliverables != null
                && Paypal_Asset.Campaign.Deliverables.Count > 0)
            {
                foreach (Deliverable del in Paypal_Asset.Campaign.Deliverables)
                {
                    #region Add Delivery Level Seeds, QAList and LinkTable
                    if (del.SeedList != null && del.SeedList.Count > 0)
                    {
                        foreach (String str in del.SeedList)
                        {
                            SeedList.Add(new SeedList() { OfferName = "ALL", EmailAddress = str });
                        }
                    }

                    if (del.TestQAList != null && del.TestQAList.Count > 0)
                    {
                        foreach (String str in del.TestQAList)
                        {
                            TestQAList.Add(new TestQAList() { OfferName = "ALL", EmailAddress = str });
                        }
                    }

                    if (del.linkTable != null && del.linkTable.Count > 0)
                    {
                        LinkTable.AddRange(del.linkTable);
                    }
                    #endregion

                    #region Add Offers Level Seeds, QAList and LinkTable
                    if (del.Offers != null && del.Offers.Count > 0)
                    {
                        foreach (Offer o in del.Offers)
                        {
                            if (o.SeedList != null && o.SeedList.Count > 0)
                            {
                                foreach (String str in o.SeedList)
                                {
                                    SeedList.Add(new SeedList() { OfferName = o.OfferName, EmailAddress = str });
                                }
                            }

                            if (o.TestQAList != null && o.TestQAList.Count > 0)
                            {
                                foreach (String str in o.TestQAList)
                                {
                                    TestQAList.Add(new TestQAList() { OfferName = o.OfferName, EmailAddress = str });
                                }
                            }

                            if (o.linkTable != null && o.linkTable.Count > 0)
                            {
                                LinkTable.AddRange(o.linkTable);
                            }
                        }
                    }
                    #endregion
                }
            }
        }
    }

    public class Paypal_Asset
    {
        public Campaign Campaign { get; set; } //= new Campaign();
        public string RecoveryModule { get; set; }
        public string FooterToApply { get; set; }
        public String MediaPlexCode { get; set; }
        public String MediaPlexTrackingPixel { get; set; }
        public String SpecialInstructions { get; set; }
        public String Asset_BoxURL { get; set; }

        public Paypal_Asset()
        {
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            MediaPlexCode = @"https://adfarm.mediaplex.com/ad/ck/29589-219905-54488-0?CampaignID=${ListID.CAMPAIGNID}&OfferId=${ListID.OFFERID}&EmailCategory=${ListID.EMAILCATEGORY}&TreatmentCode=${ListID.TREATMENTCODE}&mpre=";
            MediaPlexTrackingPixel = @"https://adfarm.mediaplex.com/ad/tr/29589-219905-54488-0?CampaignID=${ListID.CAMPAIGNID}&OfferId=${ListID.OFFERID}&EmailCategory=${ListID.EMAILCATEGORY}&TreatmentCode=${ListID.TREATMENTCODE}' border='0'>";

            RecoveryModule = "US_Merchant_Recovery Module";

            FooterToApply = "Footer_NA_US_NewsAndPromotions_Consumer";

            Campaign = new Campaign();
        }
    }

    public class PayPalCampaignBuild
    {
        public String HarmonyBusinessUnit { get; set; }
        public string HarmonyCategory { get; set; }
        public String HarmonyEmailSettings { get; set; }
        public String HarmonyFolder { get; set; }
        public String HarmonyCharacterSet { get; set; }
        public String DisplayFromName { get; set; }
        public string HarmonyEmailSetting { get; set; }

        public PayPalCampaignBuild()
        {
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            HarmonyBusinessUnit = "PayPal_NA";
            HarmonyCharacterSet = "UTF 8";
            DisplayFromName = "PayPal";
            HarmonyEmailSetting = "PayPal - USA_Default - paypal@mail.paypal.com";
            HarmonyCategory = "Marketing(Sales/Special Offer)";
        }
    }

    public class Campaign_LocaInfo
    {
        public String Epsilon_ContactBSA { get; set; }
        public String Email { get; set; }
        public String Phone { get; set; }
        public String EpsilonJobTicketNo { get; set; }

        public Campaign_LocaInfo()
        {
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            EpsilonJobTicketNo = "JT11093";
        }
    }

    public class LinkTable
    {
        public string Requestor { get; set; }
        public string EmailAddress { get; set; }
        public string Phone { get; set; }
        public string EpsilonContact { get; set; }
        public string OfferName { get; set; }
        public string Email_ContentName { get; set; }
        public string HarmonyLinkTag { get; set; }
        public string HarmonyLinkDescription { get; set; }
        public string LinkURL { get; set; }
        public string Harmony_PaypalLinkName { get; set; }
        public bool TrackURLs { get; set; }
        public bool EncodeURLs { get; set; }
        public string HarmonyLinkType { get; set; }
    }

    public class Campaign
    {
        public String RadarID { get; set; }
        public String RadarCampaignName { get; set; }
        public String MailingName { get; set; }
        public String UniqCampaignCode { get; set; }
        public String UniqCampaignName { get; set; }
        public String CampaignType { get; set; }
        public String RequestingBU { get; set; }
        public String Reccurence { get; set; }
        public String Category { get; set; }
        public String RequesterName { get; set; }
        public String RequestorEmail { get; set; }
        public String RequestorPhone { get; set; }

        public List<Deliverable> Deliverables { get; set; } //= new List<Deliverable>();

        public Campaign()
        {
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            RadarID = "NA03233";
            RadarCampaignName = "Demo campaign";
            MailingName = "Demo campaign_9_14_2016";
            UniqCampaignCode = "ABCD110023";
            UniqCampaignName = "US_201609_NA03233_CampaignTitle";
            RequesterName = "Amandeep Kirar";
            RequestorEmail = "Akirar@paypal.com";
            RequestingBU = "Canada Marketing";
            Category = "Lifecycle";
            CampaignType = "Marketing";
            Reccurence = "Adhoc";

            Deliverables = new List<Deliverable>();
            Deliverables.Add(new Deliverable("14 Sep 2016 Email"));
        }
    }

    public class SeedList
    {
        public String OfferName { get; set; }
        public String EmailAddress { get; set; }
    }

    public class TestQAList
    {
        public String OfferName { get; set; }
        public String EmailAddress { get; set; }
    }

    public class Deliverable
    {
        public String DeliverableName { get; set; }
        public String UniqueCreatives { get; set; }
        public String AssetType { get; set; }
        public String Emailopt_InPref { get; set; }
        public bool NeedResponsive { get; set; }
        public String DataFileName { get; set; }
        public string EmailSegment { get; set; }
        public string EmailType { get; set; }
        public String EmailPriority { get; set; }
        public String AttachmentDescription { get; set; }
        public DateTime DeployDate { get; set; }
        public String SubjectLineDate { get; set; }
        public DateTime EndDate { get; set; }

        public List<Offer> Offers { get; set; } //= new List<Offer>();

        public List<String> SeedList { get; set; }// = new List<string>();
        public List<String> TestQAList { get; set; }// = new List<string>();
        public List<LinkTable> linkTable { get; set; }// = new List<LinkTable>();

        public Deliverable()
        {
            SetupInitialValues();
        }
        public Deliverable(string deliverableName)
        {
            DeliverableName = deliverableName;

            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            UniqueCreatives = "1";
            AssetType = "PSD";
            Emailopt_InPref = "Account Related/Transactional (No Unsub Link)";
            //Email Segments
            EmailSegment = "Consumer";

            NeedResponsive = false;

            //Email Type
            EmailType = "Account Related (Legal, Policy,Statements, PFS)";

            SeedList = new List<string>();
            SeedList.Add("Test_DelSeed_Email1@paypal.com");
            SeedList.Add("Test_DelSeed_Email2@paypal.com");

            TestQAList = new List<string>();
            TestQAList.Add("Test_DelQA_Email1@paypal.com");
            TestQAList.Add("Test_DelQA_Email2@paypal.com");

            linkTable = new List<LinkTable>();
            linkTable.Add(new LinkTable()
            {
                OfferName = "ALL",
                EmailAddress = "TestEmail@Paypal.com",
                Email_ContentName = "Sample Content",
                EncodeURLs = true,
                EpsilonContact = "SampleEpsilonContact",
                Harmony_PaypalLinkName = "Sample Harmony_PaypalLinkName",
                HarmonyLinkDescription = "Sample HarmonyLinkDescription",
                HarmonyLinkTag = "GEN",
                HarmonyLinkType = "Form",
                LinkURL = "Sample LinkURL",
                Phone = "+1 101 202 303",
                Requestor = "Amandeep Kirar",
                TrackURLs = true
            });

            Offers = new List<Offer>();
            Offers.Add(new Offer("Offer 1"));
            Offers.Add(new Offer("Offer 2"));
            Offers.Add(new Offer("Offer 3"));
        }
    }

    public class Offer
    {
        public String OfferID { get; set; }
        public String OfferName { get; set; }
        public String Count { get; set; }
        public String AssetFileName { get; set; }
        public DateTime DeployTime { get; set; }
        public string AM_PM { get; set; }
        public String MeteringRequired { get; set; }
        public string Country { get; set; }
        public string Language { get; set; }
        public String FriendlyFromAddress { get; set; }
        public Boolean SubjectLineTestRequired { get; set; }
        public String SubjectLine1 { get; set; }
        public String SubjectLine2 { get; set; }
        public String SubjectLine3 { get; set; }
        public String SubjectLine4 { get; set; }
        public String SubjectLine5 { get; set; }

        public List<String> SeedList { get; set; } //= new List<string>();
        public List<String> TestQAList { get; set; } //= new List<string>();
        public List<LinkTable> linkTable { get; set; }
        public List<String> LinkList { get; set; }

        public Offer()
        {
            SetupInitialValues();
        }
        public Offer(string _OfferName)
        {
            OfferName = _OfferName;
            SetupInitialValues();
        }

        private void SetupInitialValues()
        {
            OfferID = OfferName + "_" + DateTime.Now.Millisecond.ToString();

            Country = "US";

            Language = "English";

            AM_PM = "PM";

            SeedList = new List<string>();
            SeedList.Add("Test_OfferSeed_Email1@paypal.com");
            SeedList.Add("Test_OfferSeed_Email2@paypal.com");

            TestQAList = new List<string>();
            TestQAList.Add("Test_OfferQA_Email1@paypal.com");
            TestQAList.Add("Test_OfferQA_Email2@paypal.com");

            linkTable = new List<LinkTable>();
            linkTable.Add(new LinkTable()
            {
                OfferName = OfferName,
                EmailAddress = "TestEmail@Paypal.com",
                Email_ContentName = "Sample Content",
                EncodeURLs = true,
                EpsilonContact = "SampleEpsilonContact",
                Harmony_PaypalLinkName = "Sample Harmony_PaypalLinkName",
                HarmonyLinkDescription = "Sample HarmonyLinkDescription",
                HarmonyLinkTag = "GEN",
                HarmonyLinkType = "Form",
                LinkURL = "Sample LinkURL",
                Phone = "+1 101 202 303",
                Requestor = "Amandeep Kirar",
                TrackURLs = true
            });
        }
    }

}