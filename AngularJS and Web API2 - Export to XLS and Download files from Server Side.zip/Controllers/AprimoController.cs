﻿using ProductsApp.Models.AprimoEntities;
using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace ProductsApp.Controllers
{
    [RoutePrefix("api/AprimoAPI")]
    public class AprimoController : ApiController
    {
        [HttpGet]
        [Route("GetConfigOptions")]
        public IHttpActionResult GetConfigOptions()
        {
            Thread.Sleep(1000);
            //return InternalServerError(new Exception("Error while fetching Config Options"));

            return Ok(new ConfigOptions());
        }

        [HttpGet]
        //[Route("GetEpsilonInfo")]
        [Route("GetEpsilonInfo/{id:int}")]
        public IHttpActionResult GetEpsilonInfo(int id)
        {
            //TODO: Extract EpsilonInfo from API, currently just using Dummy values
            if (id <= 0)
            {
                return BadRequest("Deliverable ID is not provided to API");
            }
            return Ok(new EpsilonInfo());
        }
        [HttpGet]
        [Route("Download")]
        public IHttpActionResult Download(string name)
        {
            string fileName = string.Empty;
            string ContentType = "application/octet-stream";

            if (name.Equals("pdf", StringComparison.InvariantCultureIgnoreCase))
            {
                fileName = "SamplePdf.pdf";
                //ContentType = "application/pdf";

            }
            else if (name.Equals("zip", StringComparison.InvariantCultureIgnoreCase))
            {
                fileName = "SampleZip.zip";
                //ContentType = "application/zip";
            }
            else if (name.Equals("xlsx", StringComparison.InvariantCultureIgnoreCase))
            {
                fileName = "SampleExcel.xlsx";
                //ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            }

            //if (name != "pdf" || name != "zip" || name != "xlsx")
            if(1==0)
            {
                String content = "<html><body><table><tr><td>your table</td></tr></table></body></html>";

                //var stringContent = new StringContent(jObject.ToString());
                //var response = await new HttpClient().PostAsync("http://www.sample.com/write", stringContent);
            }
            else
            {

                try
                {
                    

                    if (!string.IsNullOrEmpty(fileName))
                    {
                        string filePath = HttpContext.Current.Server.MapPath("~/Files/") + fileName;

                        using (MemoryStream ms = new MemoryStream())
                        {
                            using (FileStream file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                            {
                                byte[] bytes = new byte[file.Length];
                                file.Read(bytes, 0, (int)file.Length);
                                ms.Write(bytes, 0, (int)file.Length);

                                HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
                                httpResponseMessage.Content = new ByteArrayContent(bytes.ToArray());
                                httpResponseMessage.Content.Headers.Add("x-filename", fileName);

                                //httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                                httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue(ContentType);

                                httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                                httpResponseMessage.Content.Headers.ContentDisposition.FileName = fileName;
                                httpResponseMessage.StatusCode = HttpStatusCode.OK;

                                return ResponseMessage(httpResponseMessage);
                            }
                        }
                    }
                    return NotFound();
                }
                catch (Exception ex)
                {
                    return InternalServerError(ex);
                }
            }
        }

		[HttpPost]
		[Route("ExportReportServerSide")]
		public IHttpActionResult ExportReportServerSide()
		{
			//Make suure to JSON.stringify if passing Object
            //EpsilonInfo epsInfo = JsonConvert.DeserializeObject<EpsilonInfo>(HttpContext.Current.Request.Form["EpsilonData"]);

            var innerHTML = HttpContext.Current.Request.Unvalidated["EpsilonData"];
			HtmlGenericControl div = new HtmlGenericControl("div");
			div.InnerHtml = innerHTML;

			DateTime time = DateTime.Now;
			string format = "dMMMyyyyhh:mmtt";
			string filename = "Epsilon Report_" + time.ToString(format) + ".xls";

			StringWriter tw = new StringWriter();
			System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
			div.RenderControl(hw);

			HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + filename + "");
			HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.Unicode;
			HttpContext.Current.Response.BinaryWrite(System.Text.Encoding.Unicode.GetPreamble());
			HttpContext.Current.Response.ContentType = "application/vnd.ms-excel";

			HttpContext.Current.Response.Write(tw.ToString());
			HttpContext.Current.Response.Flush();
			HttpContext.Current.Response.SuppressContent = true;
			HttpContext.Current.ApplicationInstance.CompleteRequest();

			return Ok();

			/*
			var fileName = "SampleExcel.xlsx";
			var filePath = HttpContext.Current.Server.MapPath("~/Files/") + fileName;

			using (MemoryStream ms = new MemoryStream())
			{
				using (FileStream file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
				{
					byte[] bytes = new byte[file.Length];
					file.Read(bytes, 0, (int)file.Length);
					ms.Write(bytes, 0, (int)file.Length);

					HttpContext.Current.Response.Clear();
					HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
					HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=\"" + "SampleExcel.xlsx" + "\"");
					HttpContext.Current.Response.BinaryWrite(ms.ToArray());
					HttpContext.Current.Response.Flush();
					HttpContext.Current.Response.End();

					return Ok();

				}

			}
			*/


		}

		[HttpGet]
        [Route("ExportToExcel")]
        public IHttpActionResult ExportToExcel(string divHTML)
        {

            HtmlGenericControl dvMain = new HtmlGenericControl();
            dvMain.InnerHtml = divHTML;

            DateTime time = DateTime.Now;
            string format = "dMMMyyyyhh:mmtt";
            string filename = "SampleFile_" + time.ToString(format) + ".xls";
            StringWriter tw = new System.IO.StringWriter();
            HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
            PrepareControlForReadOnlyForm(dvMain, false);
            dvMain.RenderControl(hw);  //dvMain is the ID for top most div

            return Ok(dvMain.InnerHtml);
            //Excel export = new Excel();
            //export.ExportExcel(filename, tw);

        }

        private void PrepareControlForReadOnlyForm(Control control, bool isLocked)
        {
            for (int i = 0; i < control.Controls.Count; i++)
            {
                Control current = control.Controls[i];
                if (current.Visible == false)
                {
                    control.Controls.Remove(current);
                }
                else if (current is LinkButton)
                {
                    control.Controls.Remove(current); //control.Controls.AddAt(i, new LiteralControl((current as LinkButton).Text));
                }
                else if (current is Button && !isLocked)
                {
                    control.Controls.Remove(current);
                }
                else if (current is RegularExpressionValidator)
                {
                    control.Controls.Remove(current);
                }
                else if (current is CompareValidator)
                {
                    control.Controls.Remove(current);
                }
                else if (current is CustomValidator)
                {
                    control.Controls.Remove(current);
                }
                else if (current is HiddenField)
                {
                    control.Controls.Remove(current);
                }
                //else if (current is DateTimeControl)
                //{
                //    control.Controls.Remove(current); control.Controls.AddAt(i, new LiteralControl((current as DateTimeControl).SelectedDate.ToShortDateString()));
                //}
                else if (current is FileUpload)
                {
                    control.Controls.Remove(current);
                }
                else if (current is HyperLink)
                {
                    control.Controls.Remove(current); control.Controls.AddAt(i, new LiteralControl((current as HyperLink).Text));
                }
                else if (current is DropDownList)
                {
                    control.Controls.Remove(current); control.Controls.AddAt(i, new LiteralControl((current as DropDownList).SelectedItem.Text));
                }
                else if (current is CheckBox)
                {
                    control.Controls.Remove(current); control.Controls.AddAt(i, new LiteralControl((current as CheckBox).Checked ? "Yes" : "No"));
                }
                else if (current is TextBox)
                {
                    control.Controls.Remove(current); control.Controls.AddAt(i, new LiteralControl((current as TextBox).Text));
                }
                else if (current is RequiredFieldValidator)
                {
                    control.Controls.Remove(current);
                }
                else if (current is ValidationSummary)
                {
                    control.Controls.Remove(current);
                }
                else if (current is GridView)
                {
                    //  Create a table to contain the grid
                    Table table = new Table();
                    GridView gv = (GridView)current;
                    //  include the gridline settings
                    table.GridLines = gv.GridLines;

                    //  add the header row to the table
                    if (gv.HeaderRow != null)
                    {
                        //remove first 2 columns from grid
                        gv.HeaderRow.Cells.RemoveAt(0);
                        gv.HeaderRow.Cells.RemoveAt(0);
                        PrepareControlForReadOnlyForm(gv.HeaderRow, isLocked);
                        table.Rows.Add(gv.HeaderRow);
                    }

                    //  add each of the data rows to the table
                    foreach (GridViewRow row in gv.Rows)
                    {
                        //remove first 2 columns from grid
                        row.Cells.RemoveAt(0);
                        row.Cells.RemoveAt(0);
                        PrepareControlForReadOnlyForm(row, isLocked);
                        table.Rows.Add(row);
                    }

                    //  add the footer row to the table
                    if (gv.FooterRow != null)
                    {
                        //remove first 2 columns from grid
                        gv.FooterRow.Cells.RemoveAt(0);
                        gv.FooterRow.Cells.RemoveAt(0);
                        PrepareControlForReadOnlyForm(gv.FooterRow, isLocked);
                        table.Rows.Add(gv.FooterRow);
                    }

                    control.Controls.Remove(current); control.Controls.AddAt(i, table);
                }
                if (current.HasControls()) { PrepareControlForReadOnlyForm(current, isLocked); }
            }
        }


        [HttpGet]
        [Route("Download_OLDStyle")]
        [Obsolete("This method is depricated now, please use Download(string name).", true)]
        public HttpResponseMessage Download_OLD(string name)
        {
            try
            {
                string fileName = string.Empty;
                if (name.Equals("pdf", StringComparison.InvariantCultureIgnoreCase))
                {
                    fileName = "SamplePdf.pdf";
                }
                else if (name.Equals("zip", StringComparison.InvariantCultureIgnoreCase))
                {
                    fileName = "SampleZip.zip";
                }

                if (!string.IsNullOrEmpty(fileName))
                {
                    string filePath = HttpContext.Current.Server.MapPath("~/Files/") + fileName;

                    using (MemoryStream ms = new MemoryStream())
                    {
                        using (FileStream file = new FileStream(filePath, FileMode.Open, FileAccess.Read))
                        {
                            byte[] bytes = new byte[file.Length];
                            file.Read(bytes, 0, (int)file.Length);
                            ms.Write(bytes, 0, (int)file.Length);

                            HttpResponseMessage httpResponseMessage = new HttpResponseMessage();
                            httpResponseMessage.Content = new ByteArrayContent(bytes.ToArray());
                            httpResponseMessage.Content.Headers.Add("x-filename", fileName);
                            httpResponseMessage.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                            httpResponseMessage.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                            httpResponseMessage.Content.Headers.ContentDisposition.FileName = fileName;
                            httpResponseMessage.StatusCode = HttpStatusCode.OK;
                            return httpResponseMessage;
                        }
                    }
                }
                return this.Request.CreateResponse(HttpStatusCode.NotFound, "File not found.");
            }
            catch (Exception ex)
            {
                return this.Request.CreateResponse(HttpStatusCode.InternalServerError, ex);
            }

        }
    }
}

