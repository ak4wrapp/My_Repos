﻿using ProductsApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web.Http;

namespace ProductsApp.Controllers
{
    [RoutePrefix("api/Products")]
    public class ProductsController : ApiController
    {
        List<Product> products = new List<Product>()
        {
            new Product { Id = 1, Name = "Tomato Soup", Category = "Groceries", Price = 1 },
            new Product { Id = 2, Name = "Yo-yo", Category = "Toys", Price = 3.75M },
            new Product { Id = 3, Name = "Hammer", Category = "Hardware", Price = 16.99M }
        };

        [HttpGet]
        //[Route("GetAllProducts")]
        [Route("")]
        public IHttpActionResult GetProducts()
        {
            return Ok(products);
            //return NotFound();
        }

        [HttpGet]
        //[Route("/GetProduct/{id:int}")]
        [Route("{id:int}")]
        public IHttpActionResult GetProductByID(int id)
        {
            var product = products.FirstOrDefault((p) => p.Id == id);
            if (product == null)
            {
                return NotFound();
            }
            return Ok(product);
        }

        /*
         [Route("AddProduct")] //To use as api/Products/AddProduct
         [Route("")] //To use as api/Products/
         * */
        [Route("")]
        [HttpPost]
        public IHttpActionResult AddProduct(Product product)
        {
            if (product == null)
            {
                return BadRequest("No product found to add");
            }

            this.products.Add(product);

            return Ok(products.ToList());
        }

        [Route("AddProduct2")] //Use as api/Products/AddProduct2
        [HttpPost]
        public IHttpActionResult AddSecondProduct(Product product)
        {
            if (product == null)
            {
                return BadRequest("No product found to add");
            }

            this.products.Add(product);

            return Ok(products.ToList());
        }

        [Route("")]
        [HttpDelete]
        public IHttpActionResult DeleteProduct(Product product)
        {
            if (product == null)
            {
                return BadRequest("No product provided to delete");
            }

            // find the exact item to remove.
            var prodToDelete = this.products.FirstOrDefault(x => x.Id == product.Id);
            this.products.Remove(prodToDelete);

            return Ok(products.ToList());
        }

        [Route("{id:int}")]
        [HttpDelete]
        public IHttpActionResult DeleteProduct2(int id)
        {
            // find the exact item to remove.
            var prodToDelete = this.products.FirstOrDefault(x => x.Id == id);
            if (prodToDelete == null)
            {
                return BadRequest("No product found to delete with ID:" + id);
            }
            
            this.products.Remove(prodToDelete);

            return Ok(products.ToList());
        }

        [Route("")]
        [HttpPut]
        public IHttpActionResult UpdateProduct(Product product)
        {
            if (product == null)
            {
                return BadRequest("No product provided to delete");
            }

            // find the exact item to remove.
            var prodToupdate = this.products.FirstOrDefault(x => x.Id == product.Id);
            if (prodToupdate != null)
            {
                prodToupdate.Name = product.Name;
                prodToupdate.Category = product.Category;
                prodToupdate.Price = product.Price;

                return Ok(products.ToList());
            }
            return BadRequest("No product found to update with ID:" + product.Id);
        }
    }
}
