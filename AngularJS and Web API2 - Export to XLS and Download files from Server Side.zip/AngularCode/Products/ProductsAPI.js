﻿//app.service("APIService", ['$http', 'API_END_POINT', function ($http, API_END_POINT) {
app.service("ProductsAPI", function ($http, $q, ENV, ProductApi_END_POINT) {

    this.AddProduct = function (Product) {
        var URL = ProductApi_END_POINT;

        return $http({
            method: "POST",
            url: URL,
            withCredentials: this.SendCredentials(),
            data: JSON.stringify(Product),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        }, function (Error) {
            return Error;
        });
    };

    this.AddProduct2 = function (Product) {

        var URL = ProductApi_END_POINT + "AddProduct2";

        return $http({
            method: "POST",
            url: URL,
            withCredentials: this.SendCredentials(),
            data: JSON.stringify(Product), //Commented to raise an error
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        }, function (Error) {
            return Error;
        });
    };

    this.DeleteProduct = function (Product) {

        var URL = ProductApi_END_POINT;

        return $http({
            method: "DELETE",
            url: URL,
            withCredentials: this.SendCredentials(),
            data: JSON.stringify(Product),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        }, function (Error) {
            return Error;
        });
    };

    this.DeleteProduct2 = function (ID) {

        var URL = ProductApi_END_POINT + ID;

        return $http({
            method: "DELETE",
            url: URL,
            withCredentials: this.SendCredentials(),
            //data: JSON.stringify(Product),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        }, function (Error) {
            return Error;
        });
    };

    this.UpdateProduct = function (Product) {

        var URL = ProductApi_END_POINT;

        return $http({
            method: "PUT",
            url: URL,
            withCredentials: this.SendCredentials(),
            data: JSON.stringify(Product),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        }, function (Error) {
            return Error;
        });
    };

    this.SendCredentials = function () {
        return ((ENV === 'LOCAL') ? false : true);
    };
    this.GetHeaderValues = function () {
        return {
            "API_KEY": "X-some-key",
            "Authorization": "Basic dXNlcm5hbWU6GFzc3dvcmQ=",
            "Content-Type": "application/json"
        };
    };

    this.GetProducts = function () {

        var URL = ProductApi_END_POINT;

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.GetProductByID = function (ProductID) {

        var data = { "RequestType": "FETCH", "ProductID": ProductID };

        var URL = ProductApi_END_POINT + ProductID;

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            data: data,
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.GetEpsilonInfo = function () {

        var URL = "/api/AprimoAPI/GetEpsilonInfo";

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.PrintBaseInfo = function () {
        console.log('ENV:' + ENV + ', '
            + 'API_END_POINT:' + ProductApi_END_POINT + ', '
            + 'SendCredentials? ' + this.SendCredentials() + ", "
            + 'Header Values' + JSON.stringify(this.GetHeaderValues()));

    };
});