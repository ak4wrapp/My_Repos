﻿app.controller('ProductsController', function ($scope, $location, ProductsAPI, $timeout) {
    $scope.notification1 = {};
    $scope.notification2 = {};

    $scope.CloseAlert = function (Type) {
        console.log('Closing Alert');
        if ('Top1' === Type) {
            $scope.notification1 = {};
        }
        else if ('Top2' === Type) {
            $scope.notification2 = {};
        }
    }
    $scope.MakeFormReadOnly = false;

    $scope.ExportToExcel = function () {

        $scope.MakeFormReadOnly = true;

        $timeout(function () {
            alasql('SELECT * INTO XLSX("My Report.xlsx",{headers:false}) \
                    FROM HTML("#exportable",{headers:false})');
        }, 500);
        $scope.MakeFormReadOnly = false;      
    }
    $scope.ShowAlert = function (Type, type, message) {

        var alertID = '';
        if ('Top1' === Type) {
            alertID = "#alertTop1";

            $scope.notification1.status = 'show';
            $scope.notification1.message = message;
            $scope.notification1.type = type;
        }
        else if ('Top2' === Type) {
            alertID = "#alertTop2";

            $scope.notification2.status = 'show';
            $scope.notification2.message = message;
            $scope.notification2.type = type;
        }
        else if ('PopUp' === Type) {
            alert(message);
        }

        if ('' !== alertID) {
            $(alertID).show();
            $(alertID).fadeTo("fast", 100);

            window.setTimeout(function () {
                //$(alertID).fadeTo(500, 0);
                //$(alertID).hide();

                $(alertID).fadeTo("slow", 0).slideUp(200, function () {
                    $(this).hide();
                });
            }, 1500);
        }
    };

    $scope.reverseSort = false;


    $scope.AddRow = function () {
        index = 0;
        if ($scope.products.length > 0) {
            index = $scope.products.length - 1;
        }
        //Add a New Row copying last existing Row
        $scope.products.push(angular.copy($scope.products[index]));

        $scope.products[index + 1].Id = 0;

        this.ShowAlert('Top1', 'success', 'A new record is added.');
    }

    $scope.AddProduct = function () {

        var Product = {};
        Product.ID = 4;
        Product.Name = "New Product";
        Product.Category = "New Category";
        Product.Price = "$100.00";

        ProductsAPI.AddProduct(Product).then(function (response) {
            console.log("Response from Service for AddProduct");
            console.log(response);

            if (response.status === 200)
                $scope.products = response.data;
            else if (response.status === 403)
                console.log("Error:" + response.data)
            else
                console.log("Error:" + response.data.Message)
        });
    };

    $scope.AddProduct2 = function () {
        var Product = {};
        Product.ID = 4;
        Product.Name = "New Product 2";
        Product.Category = "New Category 2";
        Product.Price = "$200.00";

        ProductsAPI.AddProduct2(Product).then(function (response) {
            console.log("Response from Service for AddProduct2");
            console.log(response);

            if (response.status === 200)
                $scope.products = response.data;
            else if (response.status === 403)
                console.log("Error:" + response.data)
            else
                console.log("Error:" + response.data.Message)
        });
    };

    $scope.DeleteMe = function (prod) {

        ProductsAPI.DeleteProduct(prod).then(function (response) {
            console.log("Response from Service for DeleteProduct");
            console.log(response);

            if (response.status === 200)
                $scope.products = response.data;
            else if (response.status === 403)
                console.log("Error:" + response.data);
            else
                console.log("Error:" + response.data.Message);



        });

        this.ShowAlert('Top2', 'danger', 'Record is deleted.');
    }

    $scope.DeleteMe2 = function (index) {

        console.log(index);
        console.log($scope.products[index]);

        return;

        ProductsAPI.DeleteProduct2(prod.Id).then(function (response) {
            console.log("Response from Service for DeleteProduct2");
            console.log(response);

            if (response.status === 200)
                $scope.products = response.data;
            else if (response.status === 403)
                console.log("Error:" + response.data)
            else
                console.log("Error:" + response.data.Message)
        });
    }

    $scope.Update = function (prod) {
        prod.Name = "New Name";
        prod.Category = "New Category";
        prod.Price = 999;
        ProductsAPI.UpdateProduct(prod).then(function (response) {
            console.log("Response from Service for UpdateProduct");
            console.log(response);

            if (response.status === 200)
                $scope.products = response.data;
            else if (response.status === 403)
                console.log("Error:" + response.data)
            else
                console.log("Error:" + response.data.Message)

        });
    }
    $scope.LoadProducts = function () {

        //Get Query string values
        var search = $location.search();

        //See if ProductID was provided in Query String
        var productID = search.productID;
        //var SecondQueryStringParam = search.SecondQueryStringParam;
        //var ThirdQueryStringParam = search.ThirdQueryStringParam;

        if (angular.isDefined(productID)) {
            this.GetProductByID(productID);
        }
        else {
            this.GetProducts();
        }
    }

    $scope.GetProducts = function () {

        var request = ProductsAPI.GetProducts();
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (data) {
            console.log("Response from GetProducts")
            console.log(data);
            $scope.products = data;
        }, function (error) {
            if (error.status === 403)
                console.log("Error while GetProducts:" + error.data);
            else
                console.log("Error while GetProducts:" + error.data.Message);

            //console.log(error);
        });



    }

    $scope.GetProductByID = function (ProductID) {
        var request = ProductsAPI.GetProductByID(ProductID);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');
        $scope.products = [];

        request.promise.then(function (data) {
            console.log("Response from GetProducts")
            console.log(data);
            $scope.products[0] = data;
        }, function (error) {
            if (error.status === 403)
                console.log("Error while GetProducts:" + error.data)
            else
                console.log("Error while GetProducts:" + error.data.Message);

            //console.log(error);
        })
    }
})