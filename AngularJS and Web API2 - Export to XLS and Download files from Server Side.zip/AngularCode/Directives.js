﻿app.directive('notification', ['$timeout', function ($timeout) {
    return {
        restrict: 'E',
        link: link,
        scope:
		{
		    alertData: "="
		},
        template: "<div class='alert alert-{{alertData.type}}' ng-show='alertData.message' role='alert' data-notification='{{alertData.status}}'><a href='' class='close' ng-click='notificationControl.hideAlert({alertData})' aria-label='close'>&times;</a>{{alertData.message}}</div>",
        replace: true
    };

    function link(scope, el, attr) {
        scope.notificationControl = scope.control || {};
        scope.notificationControl.hideAlert = function (scopeData) {
            //el.hide();     

            //scope.alertData = {};
            scopeData.alertData.message = ""

        }
    } // link
}]);