﻿app.service("AprimoAPI", function ($http, $q, ENV, AprimoAPI_END_POINT) {

    this.SendCredentials = function () {
        return ((ENV === 'LOCAL') ? false : true);
    };

    this.GetHeaderValues = function () {
        return {
            "API_KEY": "X-some-key",
            "Authorization": "Basic dXNlcm5hbWU6GFzc3dvcmQ=",
            "Content-Type": "application/json"
        };
    };

    this.PrintBaseInfo = function () {
        console.log('ENV:' + ENV + ', '
            + 'API_END_POINT:' + AprimoAPI_END_POINT + ', '
            + 'SendCredentials? ' + this.SendCredentials() + ", "
            + 'Header Values' + JSON.stringify(this.GetHeaderValues()));

    };

    this.GetEpsilonInfo = function (DelID) {

        var URL = AprimoAPI_END_POINT + "GetEpsilonInfo/" + DelID;

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.GetConfigOptions = function () {

        var URL = AprimoAPI_END_POINT + "GetConfigOptions";

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.ExportToExcel = function (divHTML) {

        var URL = AprimoAPI_END_POINT + "ExportToExcel";

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            params: { divHTML: divHTML },
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response.data;
        });

        return { promise: promise, cancel: cancel }
    };

    this.downloadFile = function (name) {
        //Code Reference: http://jaliyaudagedara.blogspot.com/2016/05/angularjs-download-files-by-sending.html

        var URL = AprimoAPI_END_POINT + "Download";

        var canceller = $q.defer();
        var cancel = function (reason) { canceller.resolve(reason) };

        var promise = $http({
            method: "GET",
            timeout: canceller.promise,
            url: URL,
            params: { name: name },
            responseType: 'arraybuffer',
            withCredentials: this.SendCredentials(),
            headers: this.GetHeaderValues()
        }).then(function (response) {
            return response;
        });
        return { promise: promise, cancel: cancel }
    };

    this.ExportReportServerSide = function (data) {
 
        console.log('ExportReportServerSide is called');
        var URL = AprimoAPI_END_POINT + "ExportReportServerSide";

        var form = document.createElement("form");
        form.action = URL;
        form.method = "POST";
        form.target = "_self";

        var input = document.createElement("input");
        input.type = "text";
        input.name = "EpsilonData";
        input.value = data;
        form.appendChild(input);
        form.style.display = 'none';
        document.body.appendChild(form);

        form.submit();
    };


});