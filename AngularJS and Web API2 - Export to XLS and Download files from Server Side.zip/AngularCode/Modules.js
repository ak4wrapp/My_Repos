﻿var app = angular.module('APIModule', ['ngRoute']); 

//Enviornment Constants
app.constant('ProductApi_END_POINT', '/api/Products/');

app.constant('AprimoAPI_END_POINT', '/api/AprimoAPI/');

app.constant('ENV', 'LOCAL')

//For fixing Hashtag Issue, got reference from following link
//http://stackoverflow.com/questions/41211875/angularjs-1-6-0-latest-now-routes-not-working

app.config(['$locationProvider', function ($locationProvider) {
    $locationProvider.hashPrefix('');
}]);


