﻿app.config(function ($routeProvider) {
    $routeProvider
        .when("/Products", {
            controller: "ProductsController",
            templateUrl: "Pages/Products.html"
        })
        .when("/Epsilon", {
            controller: "EpsilonController",
            controllerAs: "epsCtrl",
            templateUrl: "Pages/Epsilon.html"
        })
        .when("/Test", {
            controller: "TestController",
            controllerAs: "epsCtrl",
            templateUrl: "Pages/Test.html"
        })
        .when("/ERROR", {
            template: "<b color='red' style='color: red;'>ERROR Occurred</b>"
        })
        .otherwise({ redirectTo: '/ERROR' });

})