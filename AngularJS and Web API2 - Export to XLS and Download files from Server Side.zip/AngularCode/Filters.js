﻿app.filter('hideIfEmpty', function ($filter) {
    return function (dateString, format) {

        if (dateString === '0001-01-01T00:00:00') {
            return "";
        } else {
            return $filter('date')(dateString, format.toString());
        }
    };
});