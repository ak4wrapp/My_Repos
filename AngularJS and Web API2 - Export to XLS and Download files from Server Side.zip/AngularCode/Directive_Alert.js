﻿var myApp = angular.module('myApp', []);

myApp.controller('AlertDemoCtrl', function ($scope) {

    $scope.ShowAlert = function (Type, type, message) {

        if ('Top1' === Type) {
            $scope.notification1 = {};
            $scope.notification1.status = 'show';
            $scope.notification1.message = message;
            $scope.notification1.type = type;
        }
        else if ('Top2' === Type) {
            $scope.notification2 = {};
            $scope.notification2.status = 'show';
            $scope.notification2.message = message;
            $scope.notification2.type = type;
        }
        else if ('PopUp' === Type) {
            alert(message);
        }
    };
});

myApp.directive('notification_local', ['$timeout', function ($timeout) {
    return {
        restrict: 'E',
        link: link,
        scope:
		{
		    alertData: "="
		},
        template: "<div class='alert alert-{{alertData.type}}' ng-show='alertData.message' role='alert' data-notification='{{alertData.status}}'><a href='#' class='close' ng-click='notificationControl.hideAlert({alertData: alertData})' aria-label='close'>&times;</a>{{alertData.message}}</div>",
        replace: true
    };

    function link(scope, el, attr) {
        scope.notificationControl = scope.control || {};
        scope.notificationControl.hideAlert = function (alertData) {
            //alertData is not used here for now
            //el.hide();     
            scope.alertData = {};
        }
    } // link
}]);