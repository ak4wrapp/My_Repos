﻿app.controller('EpsilonController', function ($scope, $location, $timeout, AprimoAPI) {
    $scope.Title = 'Harmony Campaign Job Request Form';
    
    $scope.SuccessAlert = {};
    $scope.ErrorAlert = {};

    $scope.ConfigOptions;
    $scope.EpsilonData;

    //$scope.ResetNotifications = function () {
    //    $scope.SuccessAlert = {};
    //    $scope.ErrorAlert = {};
    //}

    $scope.CloseAlert = function (Type) {

        if ('Success' === Type) {
            $scope.SuccessAlert = {};
        }
        else if ('Error' === Type) {
            $scope.ErrorAlert = {};
        }
    }
    $scope.ShowAlert = function (Type, type, message) {

        var alertID = '';
        if ('Success' === Type) {
            alertID = "#alertSuccess";

            $scope.SuccessAlert.status = 'show';
            $scope.SuccessAlert.message = message;
            $scope.SuccessAlert.type = type;
        }
        else if ('Error' === Type) {
            alertID = "#alertError";

            $scope.ErrorAlert.status = 'show';
            $scope.ErrorAlert.message = message;
            $scope.ErrorAlert.type = type;
        }
        else if ('PopUp' === Type) {
            alert(message);
        }

    };

    $scope.GetConfigOptions = function () {

        console.log('GetConfigOptions() is called');

        var request = AprimoAPI.GetConfigOptions();

        request.promise.then(function (data) {
            console.log(data);
            $scope.ConfigOptions = data;

            //this.GetEpsilonInfo();
            $scope.$emit('LoadEpsilonInfo');

        }, function (error) {
            if (error.status === 403) {
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    }

    $scope.GetEpsilonInfo = function () {
        //$scope.ResetNotifications();

        //Get Query string values
        var search = $location.search();

        //See if ProductID was provided in Query String
        var DelID = search.DelID;
        //var SecondQueryStringParam = search.SecondQueryStringParam;
        //var ThirdQueryStringParam = search.ThirdQueryStringParam;

        if (angular.isDefined(DelID)) {
            this.GetEpsilonInfoByDelID(DelID);
        }
        else {
            this.ShowAlert('Error', 'danger', 'Deliverable ID (?DelID=) not provided.');
        }

        //console.log($scope.ErrorAlert);
    }

    $scope.$on('ErrorOccurred', function (event, args) {
        //console.error("ErrorOccurred event is raised with Args: " + args.message);
        $scope.ShowAlert('Error', 'danger', args.message);
    });

    $scope.$on('LoadEpsilonInfo', function () {
        console.log('Loading Epsilon Info now');
        $scope.GetEpsilonInfo();
    });

    $scope.GetEpsilonInfoByDelID = function (DelID) {

        console.info("calling GetEpsilonInfoByDelID()");

        var request = AprimoAPI.GetEpsilonInfo(DelID);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (data) {
            $scope.EpsilonData = data;
            console.log($scope.EpsilonData);
        }, function (error) {
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    };

    $scope.downloadFile_WORKS_IN_CHROME = function (name) {

        var request = AprimoAPI.downloadFile(name);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (response) {

            response.headers = response.headers();

            var filename = response.headers['x-filename'];
            var contentType = response.headers['content-type'];
            console.log(filename);
            console.log(contentType);

            var linkElement = document.createElement('a');

            try {
                var blob = new Blob([response.data], { type: contentType });
                console.log(blob);
                var url = window.URL.createObjectURL(blob);

                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", filename);

                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            } catch (ex) {
                console.error(ex);
            }

        }, function (error) {
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    };

    //not used
    $scope.s2ab = function (str) {
        var buf = new ArrayBuffer(str.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != str.length; ++i) {
            view[i] = str.charCodeAt(i) & 0xFF;
        }
        return view;
    }

    $scope.MakeFormReadOnly = false;

    $scope.ToggleReadOnleMode = function () {
        $scope.MakeFormReadOnly = !$scope.MakeFormReadOnly;
    }

    $scope.ExportToExcel = function () {

        $scope.MakeFormReadOnly = true;

        $timeout(function () {

            //alasql('SELECT * INTO XLS("Test Report using alasql.xls",{headers:false}) \
            //        FROM HTML("#exportable",{headers:false})');

            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, "Test Report using FileSaver.xls");

            $scope.MakeFormReadOnly = false;

        }, 500);


        //SAMPLES

        //FILESAVER.JS --> EXPORT from Dynamic HTML
        //var HTML = "<table><thead><tr><th>Header 1</th><th>Header 2</th></tr></thead><tbody><tr><td>Item 1</td><td>Aman</td></tr><tr><td>Item 2</td><td>Renu</td></tr></tbody></table>";
        //var blob = new Blob([HTML], {
        //    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //});
        //saveAs(blob, "Report From HTML.xls");

        //FILESAVER.JS --> EXPORT from static HTMLTable using innerHTML
        //var blob = new Blob([document.getElementById('exportable').innerHTML], {
        //    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
        //});
        //saveAs(blob, "Report From HTML.xls");

        //NOTE: IF multiple/inner tables, total number of columns in excel would be as many columns in first columns
        //so add empty columns/headers in first table if inner table has more columns

        //alasql.JS --> EXPORT from exportable DIV
        //alasql('SELECT * INTO XLSX("My Report.xlsx",{headers:false}) \
        //            FROM HTML("#exportable",{headers:false})');

        //IT WORKS :)))))
        //var data1 = alasql('SELECT * FROM HTML("#table3",{headers:false})');
        //var data2 = alasql('SELECT * FROM HTML("#table4",{headers:false})');
        //var data = data1.concat(data2);
        //alasql('SELECT * INTO XLSX("Report(Multiple Table).xlsx",{headers:false}) FROM ?', [data]);
    }

    $scope.downloadFile = function (name) {

        var request = AprimoAPI.downloadFile(name);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (response) {
            try {
                var type = response.headers('Content-Type');
                var disposition = response.headers('Content-Disposition');
                if (disposition) {
                    var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                    if (match[1])
                        defaultFileName = match[1];
                }
                defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                var blob = new Blob([response.data], { type: type });
                saveAs(blob, defaultFileName);

            } catch (ex) {
                console.error(ex);
            }

        }, function (error) {
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    };
})