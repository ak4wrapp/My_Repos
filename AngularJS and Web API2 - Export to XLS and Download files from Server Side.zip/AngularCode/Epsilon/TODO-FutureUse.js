﻿
//TODO: Future Use
$scope.downloadFile_WORKS_IN_CHROME = function (name) {

    var request = AprimoAPI.downloadFile(name);
    //You can add this request to local array and provide cancel functionality
    //Add an identifier to search for this request like ID and then search this request 
    //and use request.cancel('User Cancelled');

    request.promise.then(function (response) {

        response.headers = response.headers();

        var filename = response.headers['x-filename'];
        var contentType = response.headers['content-type'];
        console.log(filename);
        console.log(contentType);

        var linkElement = document.createElement('a');

        try {
            var blob = new Blob([response.data], { type: contentType });
            console.log(blob);
            var url = window.URL.createObjectURL(blob);

            linkElement.setAttribute('href', url);
            linkElement.setAttribute("download", filename);

            var clickEvent = new MouseEvent("click", {
                "view": window,
                "bubbles": true,
                "cancelable": false
            });
            linkElement.dispatchEvent(clickEvent);
        } catch (ex) {
            console.error(ex);
        }

    }, function (error) {
        if (error.status === 403) {
            //$scope.ShowAlert('Error', 'danger', error.data);
            $scope.$emit('ErrorOccurred', { message: error.data });
        }
        else {
            //$scope.ShowAlert('Error', 'danger', error.data.Message);
            $scope.$emit('ErrorOccurred', { message: error.data.Message });
        }
    });
};





//TODO: Future Use
$scope.downloadFile = function (name) {

    var request = AprimoAPI.downloadFile(name);
    //You can add this request to local array and provide cancel functionality
    //Add an identifier to search for this request like ID and then search this request 
    //and use request.cancel('User Cancelled');

    request.promise.then(function (response) {
        try {
            var type = response.headers('Content-Type');
            var disposition = response.headers('Content-Disposition');
            if (disposition) {
                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                if (match[1])
                    defaultFileName = match[1];
            }
            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
            var blob = new Blob([response.data], { type: type });
            saveAs(blob, defaultFileName);

        } catch (ex) {
            console.error(ex);
        }

    }, function (error) {
        if (error.status === 403) {
            //$scope.ShowAlert('Error', 'danger', error.data);
            $scope.$emit('ErrorOccurred', { message: error.data });
        }
        else {
            //$scope.ShowAlert('Error', 'danger', error.data.Message);
            $scope.$emit('ErrorOccurred', { message: error.data.Message });
        }
    });
};


scope.Items = [{ name: 'India' }, { name: 'USA' }, { name: 'Russia' }, { name: 'China' }, { name: 'Australia' }, { name: 'Japan' }];
scope.selectedAll = false;

this.selectAll = function () {
    console.log('selectAll is called with value' + scope.selectedAll);
    angular.forEach(scope.Items, function (item) {
        item.Selected = scope.selectedAll;
    });
};

this.checkIfAllSelected = function () {
    scope.selectedAll = scope.Items.every(function (item) {
        return item.Selected == true
    })
};
this.DeleteSelectedItems = function () {

    var newDataList = [];

    angular.forEach(scope.Items, function (item) {
        if (item.Selected === false) {
            newDataList.push(item);
        }
    });

    if (newDataList.length === 0)
        scope.selectedAll = false;

    scope.Items = newDataList;

}


