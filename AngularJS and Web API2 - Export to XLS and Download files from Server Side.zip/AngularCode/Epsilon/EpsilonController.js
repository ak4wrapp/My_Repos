﻿app.controller('EpsilonController', function ($scope, $location, $timeout, AprimoAPI) {

    $scope.Title = 'Harmony Campaign Job Request Form';
    $scope.Processing = true;

    $scope.SuccessAlert = {};
    $scope.ErrorAlert = {};

    $scope.ConfigOptions;
    $scope.EpsilonData;

    $scope.MakeFormReadOnly = false;
    $scope.PrepareForExport = false;

    $scope.CheckBoxItems = {
        selectedAll_QA: false,
        selectedAll_Seed: false,
        selectedAll_Link: false
    }

    $scope.ModalData = {
        Index: -1,
        ModalType: "",
        Title: "",
        EmailAddress: "",
        OfferName: "ALL",
        HarmonyLinkTag: "",
        HarmonyLinkDesc: "",
        LinkURL: "",
        HarmonyPPLinkName: "",
        TrackURLs: "",
        EncodeURLs: "",
        HarmonyLinkType: ""
    }

    this.tab = 1;

    this.setTab = function (tabId) {
        this.tab = tabId;
    };

    this.isSet = function (tabId) {
        return this.tab === tabId;
    };

    this.ExportReportServerSide = function () {
        //AprimoAPI.ExportReportServerSide($scope.EpsilonData);
        //AprimoAPI.ExportReportServerSide(document.getElementById('exportable').innerHTML);

        $scope.MakeFormReadOnly = true;
        $scope.PrepareForExport = true;
        this.Processing = true;

        $timeout(function () {

            AprimoAPI.ExportReportServerSide(document.getElementById('exportable').innerHTML);

            $scope.MakeFormReadOnly = false;
            $scope.PrepareForExport = false;
            this.Processing = false;

        }, 500);
    }

    this.GetConfigOptions = function () {
        var search = $location.search();
        var DelID = search.DelID;

        if (angular.isDefined(DelID)) {
            var request = AprimoAPI.GetConfigOptions();

            request.promise.then(function (data) {
                console.log(data);
                $scope.ConfigOptions = data;

                $scope.$emit('LoadEpsilonInfo');

            }, function (error) {
                $scope.Processing = false;

                if (error.status === 403) {
                    $scope.$emit('ErrorOccurred', { message: error.data });
                }
                else {
                    $scope.$emit('ErrorOccurred', { message: error.data.ExceptionMessage });
                }
            });
        }
        else {
            $scope.Processing = false;
            $scope.$emit('ErrorOccurred', { message: 'Deliverable ID not provided.' });
        }
    }

    $scope.downloadFile = function () {

    var request = AprimoAPI.downloadFile("xlsx");
    //You can add this request to local array and provide cancel functionality
    //Add an identifier to search for this request like ID and then search this request 
    //and use request.cancel('User Cancelled');

    request.promise.then(function (response) {
        try {
            var type = response.headers('Content-Type');
            var disposition = response.headers('Content-Disposition');
            if (disposition) {
                var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                if (match[1])
                    defaultFileName = match[1];
            }
            defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
            var blob = new Blob([response.data], { type: type });
            saveAs(blob, defaultFileName);

        } catch (ex) {
            console.error(ex);
        }

    }, function (error) {
        if (error.status === 403) {
            //$scope.ShowAlert('Error', 'danger', error.data);
            $scope.$emit('ErrorOccurred', { message: error.data });
        }
        else {
            //$scope.ShowAlert('Error', 'danger', error.data.Message);
            $scope.$emit('ErrorOccurred', { message: error.data.Message });
        }
    });
};


    $scope.GetEpsilonInfoByDelID = function (DelID) {

        console.info("calling GetEpsilonInfoByDelID()");

        var request = AprimoAPI.GetEpsilonInfo(DelID);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (data) {
            $scope.EpsilonData = data;
            $scope.Processing = false;

        }, function (error) {
            $scope.Processing = false;
            if (error.status === 403) {
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                $scope.$emit('ErrorOccurred', { message: error.data.ExceptionMessage });
            }
        });
    };

    this.ToggleReadOnleMode = function () {
        $scope.MakeFormReadOnly = !$scope.MakeFormReadOnly;
    }

    this.SubmitForm = function () {

        $scope.Processing = true;
        this.GetConfigOptions();

        $timeout(function () {

            $scope.Processing = false;

        }, 5000);
    }

    this.ExportToExcel = function () {
        //this.ToggleReadOnleMode();
        //return;

        $scope.MakeFormReadOnly = true;
        $scope.PrepareForExport = true;
        this.Processing = true;

        $timeout(function () {

            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, "Test Report using FileSaver.xls");

            $scope.MakeFormReadOnly = false;
            $scope.PrepareForExport = false;
            this.Processing = false;

        }, 500);
    }

    $scope.CloseAlert = function (Type) {

        if ('Success' === Type) {
            $scope.SuccessAlert = {};
        }
        else if ('Error' === Type) {
            $scope.ErrorAlert = {};
        }
    }

    $scope.ShowAlert = function (Type, type, message) {

        var alertID = '';
        if ('Success' === Type) {
            alertID = "#alertSuccess";

            $scope.SuccessAlert.status = 'show';
            $scope.SuccessAlert.message = message;
            $scope.SuccessAlert.type = type;
        }
        else if ('Error' === Type) {
            alertID = "#alertError";

            $scope.ErrorAlert.status = 'show';
            $scope.ErrorAlert.message = message;
            $scope.ErrorAlert.type = type;
        }
        else if ('PopUp' === Type) {
            alert(message);
        }

    };

    $scope.GetEpsilonInfo = function () {
        //Get Query string values
        var search = $location.search();

        //See if DeliverableID was provided in Query String
        var DelID = search.DelID;
        //var SecondQueryStringParam = search.SecondQueryStringParam;
        //var ThirdQueryStringParam = search.ThirdQueryStringParam;

        if (angular.isDefined(DelID)) {
            this.GetEpsilonInfoByDelID(DelID);
        }
        else {
            this.ShowAlert('Error', 'danger', 'Deliverable ID (?DelID=) not provided.');
        }
    }

    $scope.$on('ErrorOccurred', function (event, args) {
        $scope.ShowAlert('Error', 'danger', args.message);
    });

    $scope.$on('LoadEpsilonInfo', function () {
        console.log('Loading Epsilon Info now');
        $scope.GetEpsilonInfo();
    });

    $scope.checkAll = function (Type) {
        if (Type === 'QA') {
            angular.forEach($scope.EpsilonData.TestQAList, function (QA) {
                QA.selected = $scope.CheckBoxItems.selectedAll_QA;
            });
        }
        else if (Type === 'SEED') {
            angular.forEach($scope.EpsilonData.SeedList, function (Seed) {
                Seed.selected = $scope.CheckBoxItems.selectedAll_Seed;
            });
        }
        else if (Type === 'LINK') {
            angular.forEach($scope.EpsilonData.LinkTable, function (Link) {
                Link.selected = $scope.CheckBoxItems.selectedAll_Link;
            });
        }

    };

    $scope.checkIfAllSelected = function (Type) {
        if (Type === 'QA') {
            $scope.CheckBoxItems.selectedAll_QA = $scope.EpsilonData.TestQAList.every(function (item) {
                return item.selected == true;
            });
        }
        else if (Type === 'SEED') {
            $scope.CheckBoxItems.selectedAll_Seed = $scope.EpsilonData.SeedList.every(function (item) {
                return item.selected == true;
            });

            console.log($scope.CheckBoxItems.selectedAll_Seed);
        }
        else if (Type === 'LINK') {
            $scope.CheckBoxItems.selectedAll_Link = $scope.EpsilonData.LinkTable.every(function (item) {
                return item.selected == true;
            });
        }
    };

    $scope.remove = function (Type) {
        var newDataList = [];
        if (Type === 'SEED') {

            angular.forEach($scope.EpsilonData.SeedList, function (Seed) {
                if (!Seed.selected) {
                    newDataList.push(Seed);
                }
            });
            $scope.EpsilonData.SeedList = newDataList;

            if (newDataList.length == 0)
                $scope.CheckBoxItems.selectedAll_Seed = false;
        }
        else if (Type === 'QA') {

            angular.forEach($scope.EpsilonData.TestQAList, function (QA) {
                if (!QA.selected) {
                    newDataList.push(QA);
                }
            });
            $scope.EpsilonData.TestQAList = newDataList;

            if (newDataList.length == 0)
                $scope.CheckBoxItems.selectedAll_QA = false;
        }
        else if (Type === 'LINK') {

            angular.forEach($scope.EpsilonData.LinkTable, function (Link) {
                if (!Link.selected) {
                    newDataList.push(Link);
                }
            });
            $scope.EpsilonData.LinkTable = newDataList;

            if (newDataList.length == 0)
                $scope.CheckBoxItems.selectedAll_Link = false;
        }
    };

    $scope.CopyRow = function (Type, Row) {
        console.log(Row);
        if (Type === 'LINK') {
            var newRow = angular.copy(Row);
            $scope.EpsilonData.LinkTable.push(newRow);
        }
    };

    $scope.OpenModel = function (Type) {
        $scope.ModalData = {};
        $scope.ModalData.Index = -1;
        $scope.ModalData.ModalType = Type;
        $scope.ModalData.Title = "Add " + Type;
        $scope.ModalData.OfferName = "ALL"

        if (Type === 'LINK') {
            $('#MyModalPopUp_LINK').modal('show');
        }
        else {
            $('#MyModalPopUp').modal('show');
        }
    }

    $scope.addNew = function () {
        console.log($scope.ModalData.ModalType);
        if ($scope.ModalData.ModalType === 'SEED') {
            $scope.EpsilonData.SeedList.push({
                "EmailAddress": $scope.ModalData.EmailAddress,
                "OfferName": $scope.ModalData.OfferName
            });

            $('#MyModalPopUp').modal('hide');

        }
        else if ($scope.ModalData.ModalType === 'QA') {
            $scope.EpsilonData.TestQAList.push({
                "EmailAddress": $scope.ModalData.EmailAddress,
                "OfferName": $scope.ModalData.OfferName
            });

            $('#MyModalPopUp').modal('hide');
        }
        else if ($scope.ModalData.ModalType === 'LINK') {
            console.log($scope.ModalData);

            $scope.EpsilonData.LinkTable.push({
                "OfferName": $scope.ModalData.OfferName,
                "EmailAddress": $scope.ModalData.EmailAddress,
                "HarmonyLinkTag": $scope.ModalData.HarmonyLinkTag,
                "HarmonyLinkDescription": $scope.ModalData.HarmonyLinkDesc,
                "LinkURL": $scope.ModalData.LinkURL,
                "Harmony_PaypalLinkName": $scope.ModalData.HarmonyPPLinkName,
                "TrackURLs": $scope.ModalData.TrackURLs,
                "EncodeURLs": $scope.ModalData.EncodeURLs,
                "HarmonyLinkType": $scope.ModalData.HarmonyLinkType
            });

            $('#MyModalPopUp_LINK').modal('hide');
        }

    };

    $scope.edit = function (Item, Index, Type) {
        console.log(Item);

        $scope.ModalData.Index = Index;
        $scope.ModalData.EmailAddress = Item.EmailAddress;
        $scope.ModalData.OfferName = Item.OfferName;
        $scope.ModalData.ModalType = Type;
        $scope.ModalData.Title = "Edit " + Type;


        if (Type === 'LINK') {
            $scope.ModalData.HarmonyLinkTag = Item.HarmonyLinkTag;
            $scope.ModalData.HarmonyLinkDesc = Item.HarmonyLinkDescription;
            $scope.ModalData.LinkURL = Item.LinkURL;
            $scope.ModalData.HarmonyPPLinkName = Item.Harmony_PaypalLinkName;
            $scope.ModalData.TrackURLs = Item.TrackURLs;
            $scope.ModalData.EncodeURLs = Item.EncodeURLs;
            $scope.ModalData.HarmonyLinkType = Item.HarmonyLinkType;


            console.log($scope.ModalData);

            $('#MyModalPopUp_LINK').modal('show');
        }
        else {
            $('#MyModalPopUp').modal('show');
        }
    };

    $scope.updateList = function () {
        console.log($scope.ModalData.ModalType);
        if ($scope.ModalData.ModalType === 'SEED') {
            $scope.EpsilonData.SeedList[$scope.ModalData.Index].EmailAddress = $scope.ModalData.EmailAddress;
            $scope.EpsilonData.SeedList[$scope.ModalData.Index].OfferName = $scope.ModalData.OfferName;

            $('#MyModalPopUp').modal('hide');
        }
        else if ($scope.ModalData.ModalType === 'QA') {

            $scope.EpsilonData.TestQAList[$scope.ModalData.Index].EmailAddress = $scope.ModalData.EmailAddress;
            $scope.EpsilonData.TestQAList[$scope.ModalData.Index].OfferName = $scope.ModalData.OfferName;

            $('#MyModalPopUp').modal('hide');
        }
        else if ($scope.ModalData.ModalType === 'LINK') {
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].OfferName = $scope.ModalData.OfferName;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].EmailAddress = $scope.ModalData.EmailAddress;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].HarmonyLinkTag = $scope.ModalData.HarmonyLinkTag;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].HarmonyLinkDescription = $scope.ModalData.HarmonyLinkDesc;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].LinkURL = $scope.ModalData.LinkURL;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].Harmony_PaypalLinkName = $scope.ModalData.HarmonyPPLinkName;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].TrackURLs = $scope.ModalData.TrackURLs;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].EncodeURLs = $scope.ModalData.EncodeURLs;
            $scope.EpsilonData.LinkTable[$scope.ModalData.Index].HarmonyLinkType = $scope.ModalData.HarmonyLinkType;

            $('#MyModalPopUp_LINK').modal('hide');
        }

    }
})