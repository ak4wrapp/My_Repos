﻿app.controller('TestController', function ($scope, $location, $timeout, AprimoAPI) {

    $scope.Title = 'Harmony Campaign Job Request Form';
    $scope.Processing = true;

    $scope.SuccessAlert = {};
    $scope.ErrorAlert = {};

    $scope.ConfigOptions;
    $scope.EpsilonData;

    this.tab = 1;
    this.setTab = function (tabId) {
        this.tab = tabId;
    };

    this.isSet = function (tabId) {
        return this.tab === tabId;
    };



    $scope.selectedAll_LINK = true;
    $scope.selectAll_LINK = function () {
        console.log('selectAll is called with value:' + $scope.selectedAll_LINK);
        angular.forEach($scope.EpsilonData.LinkTable, function (item) {
            console.log(item.Selected + ":" + $scope.selectedAll_LINK);
            item.Selected = $scope.selectedAll_LINK;
            console.log(item.Selected + ":" + $scope.selectedAll_LINK);
        });
    };

    $scope.checkIfAllSelected_LINK = function () {
        this.selectedAll_LINK = $scope.EpsilonData.LinkTable.every(function (item) {
            return item.Selected == true
        })
    };


    $scope.Items = [{ name: 'India' }, { name: 'USA' }, { name: 'Russia' }, { name: 'China' }, { name: 'Australia' }, { name: 'Japan' }];
    $scope.selectedAll = false; 
    this.selectAll = function () {
        console.log('selectAll is called with value' + $scope.selectedAll);
        angular.forEach(scope.Items, function (item) {
            item.Selected = $scope.selectedAll;
        });
    };

    this.checkIfAllSelected = function () {
        $scope.selectedAll = $scope.Items.every(function (item) {
            return item.Selected == true
        })
    };
    this.DeleteSelectedItems = function () {

        var newDataList = [];

        angular.forEach(scope.Items, function (item) {
            if (item.Selected === false) {
                newDataList.push(item);
            }
        });

        if (newDataList.length === 0)
            scope.selectedAll = false;

        $scope.Items = newDataList;

    }


    this.GetConfigOptions = function () {
        var search = $location.search();
        var DelID = search.DelID;

        if (angular.isDefined(DelID)) {
            var request = AprimoAPI.GetConfigOptions();

            request.promise.then(function (data) {
                console.log(data);
                $scope.ConfigOptions = data;
                $scope.$emit('LoadEpsilonInfo');

            }, function (error) {
                $scope.Processing = false;

                if (error.status === 403) {
                    $scope.$emit('ErrorOccurred', { message: error.data });
                }
                else {
                    $scope.$emit('ErrorOccurred', { message: error.data.ExceptionMessage });
                }
            });
        }
        else {
            $scope.Processing = false;
            $scope.$emit('ErrorOccurred', { message: 'Deliverable ID not provided.' });
        }
    }



    $scope.GetEpsilonInfoByDelID = function (DelID) {

        console.info("calling GetEpsilonInfoByDelID()");

        var request = AprimoAPI.GetEpsilonInfo(DelID);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (data) {
            $scope.EpsilonData = data;
            $scope.Processing = false;

        }, function (error) {
            $scope.Processing = false;
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.ExceptionMessage });
            }
        });
    };


    $scope.MakeFormReadOnly = false;
    $scope.PrepareForExport = false;

    this.ToggleReadOnleMode = function () {
        $scope.MakeFormReadOnly = !$scope.MakeFormReadOnly;
    }

    this.SubmitForm = function () {

        $scope.Processing = true;
        scope.GetConfigOptions();

        $timeout(function () {

            $scope.Processing = false;

        }, 5000);
    }

    this.ExportToExcel = function () {
        //this.ToggleReadOnleMode();
        //return;

        $scope.MakeFormReadOnly = true;
        $scope.PrepareForExport = true;
        this.Processing = true;

        $timeout(function () {

            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"
            });
            saveAs(blob, "Test Report using FileSaver.xls");

            $scope.MakeFormReadOnly = false;
            $scope.PrepareForExport = false;
            this.Processing = false;

        }, 500);
    }

    $scope.CloseAlert = function (Type) {

        if ('Success' === Type) {
            $scope.SuccessAlert = {};
        }
        else if ('Error' === Type) {
            $scope.ErrorAlert = {};
        }
    }
    $scope.ShowAlert = function (Type, type, message) {

        var alertID = '';
        if ('Success' === Type) {
            alertID = "#alertSuccess";

            $scope.SuccessAlert.status = 'show';
            $scope.SuccessAlert.message = message;
            $scope.SuccessAlert.type = type;
        }
        else if ('Error' === Type) {
            alertID = "#alertError";

            $scope.ErrorAlert.status = 'show';
            $scope.ErrorAlert.message = message;
            $scope.ErrorAlert.type = type;
        }
        else if ('PopUp' === Type) {
            alert(message);
        }

    };



    $scope.GetEpsilonInfo = function () {
        //$scope.ResetNotifications();

        //Get Query string values
        var search = $location.search();

        //See if ProductID was provided in Query String
        var DelID = search.DelID;
        //var SecondQueryStringParam = search.SecondQueryStringParam;
        //var ThirdQueryStringParam = search.ThirdQueryStringParam;

        if (angular.isDefined(DelID)) {
            this.GetEpsilonInfoByDelID(DelID);
        }
        else {
            this.ShowAlert('Error', 'danger', 'Deliverable ID (?DelID=) not provided.');
        }

        //console.log($scope.ErrorAlert);
    }

    $scope.$on('ErrorOccurred', function (event, args) {

        //console.error("ErrorOccurred event is raised with Args: " + args.message);
        $scope.ShowAlert('Error', 'danger', args.message);
    });

    $scope.$on('LoadEpsilonInfo', function () {
        console.log('Loading Epsilon Info now');
        $scope.GetEpsilonInfo();
    });




    //TODO: Future Use
    $scope.downloadFile_WORKS_IN_CHROME = function (name) {

        var request = AprimoAPI.downloadFile(name);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (response) {

            response.headers = response.headers();

            var filename = response.headers['x-filename'];
            var contentType = response.headers['content-type'];
            console.log(filename);
            console.log(contentType);

            var linkElement = document.createElement('a');

            try {
                var blob = new Blob([response.data], { type: contentType });
                console.log(blob);
                var url = window.URL.createObjectURL(blob);

                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", filename);

                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            } catch (ex) {
                console.error(ex);
            }

        }, function (error) {
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    };






    $scope.checkAllQA = function () {
        if (!$scope.selectedAll_QA) {
            $scope.selectedAll_QA = true;
        } else {
            $scope.selectedAll_QA = false;
        }
        angular.forEach($scope.EpsilonData.TestQAList, function (QA) {
            QA.selected = $scope.selectedAll_QA;
        });
    };

    $scope.checkAllSeed = function () {
        if (!$scope.selectedAll_Seed) {
            $scope.selectedAll_Seed = true;
        } else {
            $scope.selectedAll_Seed = false;
        }
        angular.forEach($scope.EpsilonData.SeedList, function (Seed) {
            Seed.selected = $scope.selectedAll_Seed;
        });

        console.log($scope.selectedAll_Seed);
    };


    $scope.ModalData = {
        ModalHeader: "",
        ModalType: "",
        Title: "",
        EmailAddress: "",
        OfferName: "ALL",
        Index: -1
    }

    $scope.OpenModel = function (Type) {
        $scope.ModalData.Index = -1;
        $scope.ModalData.EmailAddress = '';
        $scope.ModalType = Type;
        $scope.ModalData.Title = "Manage " + Type;
        $('#MyModalPopUp').modal('show');
    }
    $scope.addNew = function () {

        if ($scope.ModalType === 'Seed') {
            $scope.EpsilonData.SeedList.push({
                "EmailAddress": $scope.ModalData.EmailAddress,
                "OfferName": $scope.ModalData.OfferName
            });
        }
        else if ($scope.ModalType === 'QA') {
            $scope.EpsilonData.TestQAList.push({
                "EmailAddress": $scope.ModalData.EmailAddress,
                "OfferName": $scope.ModalData.OfferName
            });
        }
        //
        $('#MyModalPopUp').modal('hide');
    };

    //edit Seed/QA
    $scope.edit = function (Item, Index, Type) {

        console.log(Type);
        $scope.ModalData.EmailAddress = Item.EmailAddress;
        $scope.ModalData.OfferName = Item.OfferName;
        $scope.ModalData.Index = Index;
        $scope.ModalData.ModalType = Type;

        $('#MyModalPopUp').modal('show');
    };

    //TODO: Updated based on which field?
    $scope.updateList = function () {
        console.log($scope.ModalData.ModalType);
        if ($scope.ModalData.ModalType === 'Seed') {
            $scope.EpsilonData.SeedList[$scope.ModalData.Index].EmailAddress = $scope.ModalData.EmailAddress;
            $scope.EpsilonData.SeedList[$scope.ModalData.Index].OfferName = $scope.ModalData.OfferName;
        }
        else if ($scope.ModalData.ModalType === 'QA') {

            $scope.EpsilonData.TestQAList[$scope.ModalData.Index].EmailAddress = $scope.ModalData.EmailAddress;
            $scope.EpsilonData.TestQAList[$scope.ModalData.Index].OfferName = $scope.ModalData.OfferName;
        }
        $('#MyModalPopUp').modal('hide');
    }

    $scope.remove = function (Type) {
        console.log($scope.selectedAll_Seed);
        var newDataList = [];
        if (Type === 'Seed') {
            $scope.selectedAll_Seed = false;
            angular.forEach($scope.EpsilonData.SeedList, function (Seed) {
                if (!Seed.selected) {
                    newDataList.push(Seed);
                }
            });
            $scope.EpsilonData.SeedList = newDataList;
        }
        else if (Type === 'QA') {
            $scope.selectedAll_QA = false;
            angular.forEach($scope.EpsilonData.TestQAList, function (QA) {
                if (!QA.selected) {
                    newDataList.push(QA);
                }
            });
            $scope.EpsilonData.TestQAList = newDataList;
        }

        console.log($scope.selectedAll_Seed);
    };


    //TODO: Future Use
    $scope.downloadFile = function (name) {

        var request = AprimoAPI.downloadFile(name);
        //You can add this request to local array and provide cancel functionality
        //Add an identifier to search for this request like ID and then search this request 
        //and use request.cancel('User Cancelled');

        request.promise.then(function (response) {
            try {
                var type = response.headers('Content-Type');
                var disposition = response.headers('Content-Disposition');
                if (disposition) {
                    var match = disposition.match(/.*filename=\"?([^;\"]+)\"?.*/);
                    if (match[1])
                        defaultFileName = match[1];
                }
                defaultFileName = defaultFileName.replace(/[<>:"\/\\|?*]+/g, '_');
                var blob = new Blob([response.data], { type: type });
                saveAs(blob, defaultFileName);

            } catch (ex) {
                console.error(ex);
            }

        }, function (error) {
            if (error.status === 403) {
                //$scope.ShowAlert('Error', 'danger', error.data);
                $scope.$emit('ErrorOccurred', { message: error.data });
            }
            else {
                //$scope.ShowAlert('Error', 'danger', error.data.Message);
                $scope.$emit('ErrorOccurred', { message: error.data.Message });
            }
        });
    };
})